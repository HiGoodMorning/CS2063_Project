package com.example.ddd;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static int selectedImage;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;

    Intent MainToOb;

    public void bgSelected() {
        Toast.makeText(this, "Background image selected", Toast.LENGTH_SHORT).show();
        startActivity(MainToOb);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bg);
        MainToOb = new Intent (MainActivity.this, ob.class);

        btn1 = (Button) findViewById(R.id.imageButton1);
        btn2 = (Button) findViewById(R.id.imageButton2);
        btn3 = (Button) findViewById(R.id.imageButton3);
        btn4 = (Button) findViewById(R.id.imageButton4);
        btn5 = (Button) findViewById(R.id.imageButton5);
        btn6 = (Button) findViewById(R.id.imageButton6);
        btn7 = (Button) findViewById(R.id.imageButton7);
        btn8 = (Button) findViewById(R.id.imageButton8);
        btn9 = (Button) findViewById(R.id.imageButton9);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imageButton1:
                selectedImage = R.drawable.bg1;
                bgSelected();
                break;
            case R.id.imageButton2:
                selectedImage = R.drawable.bg2;
                bgSelected();
                break;
            case R.id.imageButton3:
                selectedImage = R.drawable.bg3;
                bgSelected();
                break;
            case R.id.imageButton4:
                selectedImage = R.drawable.bg4;
                bgSelected();
                break;
            case R.id.imageButton5:
                selectedImage = R.drawable.bg5;
                bgSelected();
                break;
            case R.id.imageButton6:
                selectedImage = R.drawable.bg6;
                bgSelected();
                break;
            case R.id.imageButton7:
                selectedImage = R.drawable.bg7;
                bgSelected();
                break;
            case R.id.imageButton8:
                selectedImage = R.drawable.bg8;
                bgSelected();
                break;
            case R.id.imageButton9:
                selectedImage = R.drawable.bg9;
                bgSelected();
                break;
        }
    }
    public static int getSelectedImage() {
        return selectedImage;
    }
}

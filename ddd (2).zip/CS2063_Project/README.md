# CS2063_Project

##############
Check out following pages to set up Your 'First' Git res :)

1) First time Git Set-up

첫번째, 컴퓨터에 깃허브 등록하기
이 단계에 앞서 깃허브에 회원가입을 했기를 바람

https://git-scm.com/book/en/v2/Getting-Started-First-Time-Git-Setup

2) Cloning a Github project

두번째, 깃허브를 등록한 컴퓨터에 깃허브 프로젝트 다운받기

https://help.github.com/articles/cloning-a-repository/

3) Creating a new branch

** 중요 **
일단 프로젝트를 다운받았을시 브랜치는 마스터와 연결됨,
하지만 마스터는 최종 형태의 코드, 즉 함부로 하면안됨 그러므로 새로운 브랜치를 만들어서 코드를 끄적이길바람

잠깐 여기서 브랜치란,
마스터의 아이? 무튼 만들고 나중에 잘된다 싶으면 마스터랑 합치길 바람 안그럼 망함


https://github.com/Kunena/Kunena-Forum/wiki/Create-a-new-branch-with-git-and-manage-branches

4) Fetching and pulling git hub

최신 코드로 업데이트 하는법
차이점 https://stackoverflow.com/questions/292357/what-is-the-difference-between-git-pull-and-git-fetch

**차이를 꼭 확인하자

Fetch - https://git-scm.com/docs/git-fetch
Pull - https://git-scm.com/docs/git-pull

5) Adding and Commiting your work

터미널의 이용하여 자신이 쓴 코드를 깃허브에 올리기
**되도록이면 마스터 브랜치로 바로 넣는건 안하길바람

https://git-scm.com/docs/git-commit

6) Pull request

자신이 만든 브랜치와 마스터 브랜치의 합체하는 과정
**일단 자기꺼 되면 해야됨

https://yangsu.github.io/pull-request-tutorial/

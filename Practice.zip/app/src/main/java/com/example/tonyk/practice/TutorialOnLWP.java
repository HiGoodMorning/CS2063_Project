package com.example.tonyk.practice;

import android.os.Bundle;
import android.app.Activity;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TutorialOnLWP extends Activity {
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mt("App loaded");
        setContentView(R.layout.activity_tutorial_on_lwp);

        btn1 = (Button) findViewById(R.id.button);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(TutorialOnLWP.this,MainActivity.class);

//startActivity(intent1);

                startActivityForResult(intent1,1);
            }
        });

    }


    public void mt(String string){
       Toast.makeText(this, string, Toast.LENGTH_SHORT).show();
   }
}

